desvincularCliente:; 
	call limpaTela
	mov si,msgDesvincularCliente
	call printString
	call delay


	mov cl,al
	mov ax,46
	mul cl
	;shift do cliente já está em ax
	mov si,memoria
	add si,ax
	;;;;;;;;;

	;Zerando
	mov cx,0
	limpandoDados:
		inc cx
		cmp cx,45

		mov byte[si],0
		inc si

		je fimDesvincula
	;fim dolaço



	fimDesvincula:


	
	ret
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

