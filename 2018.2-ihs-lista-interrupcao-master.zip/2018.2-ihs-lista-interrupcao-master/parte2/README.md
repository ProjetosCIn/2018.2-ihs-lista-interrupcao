# Projeto Banco de Dados
Primeira atividade da disciplina IHS.

## Autores
- Luiz Antonio
- Thiago Augusto
- Rafael
- José Brandão
- Marco

## Como rodar o kernel

Basta abrir o terminal e até a pasta onde estão os arquivos e executar:

`make all`
